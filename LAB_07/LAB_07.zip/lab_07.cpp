#include <iostream>
#include <vector>
#include "SetContainer.h"

int main(){
    SetContainer A, B, C, D, E;

    A.insert(1); A.insert(2); A.insert(3);
    B.insert(2); B.insert(3); B.insert(4);
    C.insert(3); C.insert(4); C.insert(5);
    D.insert(4); D.insert(5); D.insert(6);
    E.insert(5); E.insert(6); E.insert(7);

    cout << "A :";
    A.printSet();
    cout << "B :";
    B.printSet();
    cout << "C :";
    C.printSet();
    cout << "D :";
    D.printSet();
    cout << "E :";
    E.printSet();

    SetContainer BC = B.intersection(C);
    std::cout << "B with C: ";
    BC.printSet();

    SetContainer AB_C = A.unionSet(BC);
    std::cout << "A + (B with C): ";
    AB_C.printSet();

    SetContainer AB_C_D = AB_C.difference(D);
    std::cout << "(A + (B with C)) \\ D: ";
    AB_C_D.printSet();

    SetContainer finalResult = AB_C_D.intersection(E);
    std::cout << "Final Result: ";
    finalResult.printSet();


    A.setValues(A.erase(1, 2));
    A.printSet();

    B.setValues(B.subst(C.getValues(), 3));
    B.printSet();

    C.setValues(C.change(E.getValues(), 0));
    C.printSet();
    return 0;
}